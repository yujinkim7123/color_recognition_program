// index.js
const http = require('http');
const express = require('express');
const app = express();
const server = http.createServer(app);

app.get('/', (req, res) => {
	res.send('Hello express!!!');
});


server.listen(3000);