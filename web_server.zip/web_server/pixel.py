from PIL import Image
import matplotlib.pyplot as plt

path = '/data/2030/BileDuct/TestImage/mask/10.png'

# 이미지 열기
image = Image.open(path)
plt.imshow(image)

colors = image.getcolors()
print(colors)