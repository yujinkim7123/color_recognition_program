import os
import cv2
import warnings
import numpy as np
from sklearn.cluster import KMeans
from tqdm import tqdm

folder_paths = ['./image']

img_path = []
for fp in folder_paths :
    images = [os.path.join(fp,f) for f in os.listdir(fp) if f.lower().endswith('.jpg')]
    print(images)
    img_path.extend(images)

def extract_rgb_values(image_path):
    # 이미지 불러오기
    image = cv2.imread(image_path)
    # 이미지의 높이와 너비 가져오기
    height, width, _ = image.shape

    # 픽셀별 RGB 값을 추출하여 리스트로 반환
    rgb_values = []
    for y in range(height):
        for x in range(width):
            pixel_value = image[y, x]
            rgb_values.append(pixel_value)

    return rgb_values

def find_optimal_clusters(image_path, max_clusters=10):
    # 이미지에서 RGB 값을 추출
    rgb_values = extract_rgb_values(image_path)

        # NumPy 배열로 변환
    rgb_array = np.array(rgb_values)

        # 클러스터 수에 따른 K-Means inertia 계산
    inertias = []
    for i in range(1, max_clusters + 1):
        kmeans = KMeans(n_clusters=i, random_state=42)
        kmeans.fit(rgb_array)
        inertias.append(kmeans.inertia_)

        # Elbow Method를 통해 최적의 클러스터 수 찾기
    optimal_clusters = inertias.index(min(inertias)) + 1

        # 최적의 클러스터 수로 K-Means 클러스터링 수행
    kmeans = KMeans(n_clusters=optimal_clusters, random_state=42)
    kmeans.fit(rgb_array)

        # 각 클러스터의 레이블 가져오기
    labels = kmeans.labels_

        # 가장 많은 픽셀을 가지고 있는 클러스터의 인덱스 찾기
    dominant_cluster_index = np.argmax(np.bincount(labels))

        # 가장 많은 픽셀을 가지고 있는 클러스터의 중심 좌표 가져오기
    dominant_color_center = kmeans.cluster_centers_[dominant_cluster_index]

    return dominant_color_center
    
warnings.filterwarnings("ignore")

colors = []

for i in tqdm(img_path) :
  dominant_color = find_optimal_clusters(i)
  colors.append(dominant_color)

print(f"Dominant Color (R, G, B) of the Largest Cluster:")
print(f"R: {int(dominant_color[0])}, G: {int(dominant_color[1])}, B: {int(dominant_color[2])}")