let fun_fiter ,type

function chageLangSelect(){
    var langSelect = document.getElementById("selectbox");
    var selectValue = langSelect.options[langSelect.selectedIndex].value;
    return selectValue;
}

function getFilterFunction() {
    var name = document.getElementById("method");
    var selectValue = name.options[name.selectedIndex].value;
    if (selectValue === 'hcirn') {
        lib = fBlind;
    } else if (selectValue === 'simpl') {
        lib = colorMatrixFilterFunctions;
    } else if (selectValue === 'brett') {
        lib = brettelFunctions;
    } else if (selectValue === "macha") {
       
        //return getMachadoMatrix(type.substring(5), parseInt(document.getElementById('severity').value, 10));
    } else {
        throw 'Invalid Filter Type!';
    }

    return lib;

}